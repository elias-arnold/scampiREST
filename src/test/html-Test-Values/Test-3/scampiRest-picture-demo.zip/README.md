# scampiRest-picture-demo
AngularJS App as a demo for the scampiRest API
